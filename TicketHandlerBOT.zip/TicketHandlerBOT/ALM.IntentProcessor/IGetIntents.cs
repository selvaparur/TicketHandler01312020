﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;


namespace ALM.IntentProcessor
{
   public interface IGetIntents
    {
        string GetIntent(string strQuery);

        string ProcessIntent(ITurnContext<IMessageActivity> turnContext);
    }
}
