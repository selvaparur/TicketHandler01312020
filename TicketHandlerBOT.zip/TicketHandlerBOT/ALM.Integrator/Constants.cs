﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ALM.Integrator
{
    public static class Constants
    {
        public const string JIRAStoryNumber = "?storyNumber=";
    }
}
